import { UserManager, WebStorageStateStore } from
  "https://cdn.jsdelivr.net/npm/oidc-client-ts@3.4.1/+esm";
import { CONFIG } from "./config.js";

const $ = (id) => document.getElementById(id);

const manager = new UserManager({
  authority: CONFIG.COGNITO_AUTHORITY,
  client_id: CONFIG.CLIENT_ID,
  redirect_uri: CONFIG.REDIRECT_URI,
  post_logout_redirect_uri: CONFIG.POST_LOGOUT_REDIRECT_URI,
  response_type: "code",
  scope: "openid email phone",
  userStore: new WebStorageStateStore({ store: window.sessionStorage }),
  automaticSilentRenew: false
});

let posts = [];

function configReady() {
  return (
    !CONFIG.CLIENT_ID.includes("PASTE_") &&
    !CONFIG.COGNITO_DOMAIN.includes("PASTE_")
  );
}

async function init() {
  $("footerTime").textContent =
    new Intl.DateTimeFormat("en-IN", {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "Asia/Kolkata"
    }).format(new Date()) + " IST";

  // If Cognito redirected back with ?code=..., finish the authorization flow.
  if (window.location.search.includes("code=")) {
    try {
      await manager.signinCallback();
      window.history.replaceState({}, document.title, window.location.pathname);
    } catch (err) {
      console.error(err);
      $("loginError").textContent =
        "Login callback failed. Check the Cognito callback URL and App Client ID.";
    }
  }

  const user = await manager.getUser();

  if (user && !user.expired) {
    showDashboard(user);
    await loadPosts(user);
  } else {
    showLogin();
  }
}

function showLogin() {
  $("loginPanel").classList.remove("hidden");
  $("dashboard").classList.add("hidden");
  $("userEmail").textContent = "";
}

function showDashboard(user) {
  $("loginPanel").classList.add("hidden");
  $("dashboard").classList.remove("hidden");

  const email =
    user.profile?.email ||
    user.profile?.["cognito:username"] ||
    "Admin";
  $("userEmail").textContent = email;
}

async function login() {
  $("loginError").textContent = "";

  if (!configReady()) {
    $("loginError").textContent =
      "Complete config.js first: add the Cognito App Client ID and Managed Login domain.";
    return;
  }

  await manager.signinRedirect({
    extraQueryParams: {
      identity_provider: "COGNITO"
    }
  });
}

async function logout() {
  try {
    await manager.signoutRedirect();
  } catch (err) {
    console.error(err);
    await manager.removeUser();
    showLogin();
  }
}

async function getAccessToken() {
  const user = await manager.getUser();

  if (!user || user.expired) {
    await manager.signinRedirect();
    throw new Error("Authentication required.");
  }

  return user.access_token;
}

async function apiRequest(path, options = {}) {
  const token = await getAccessToken();

  const headers = {
    ...(options.body ? { "Content-Type": "application/json" } : {}),
    ...(options.headers || {}),
    Authorization: `Bearer ${token}`
  };

  const response = await fetch(`${CONFIG.API_BASE_URL}${path}`, {
    ...options,
    headers
  });

  const text = await response.text();
  let data;

  try {
    data = JSON.parse(text);
  } catch {
    data = { message: text };
  }

  if (!response.ok) {
    throw new Error(data.message || `API request failed (${response.status})`);
  }

  return data;
}

async function loadPosts(user) {
  $("apiStatus").textContent = "Checking…";

  try {
    // GET is public in the current API, but using the authenticated token here
    // keeps the frontend ready for a future protected configuration.
    const token = user?.access_token;
    const response = await fetch(`${CONFIG.API_BASE_URL}/blogs`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    });

    if (!response.ok) throw new Error(`GET /blogs returned ${response.status}`);

    const data = await response.json();
    posts = data.posts || data.items || data.data || [];
    $("postCount").textContent = data.count ?? posts.length;
    $("apiStatus").textContent = "Online";
    renderPosts();
  } catch (err) {
    console.error(err);
    $("apiStatus").textContent = "Error";
    $("postsList").innerHTML =
      `<div class="empty">Could not load posts.<br>${escapeHtml(err.message)}</div>`;
  }
}

function renderPosts() {
  if (!posts.length) {
    $("postsList").innerHTML = `<div class="empty">No blog posts found.</div>`;
    return;
  }

  $("postsList").innerHTML = posts.map((post) => `
    <article class="post-item">
      <div class="post-top">
        <div>
          <h3>${escapeHtml(post.title || "Untitled")}</h3>
          <p>${escapeHtml(post.excerpt || post.content || "")}</p>
        </div>
        <span class="badge ${post.status === "draft" ? "draft" : "published"}">
          ${escapeHtml(post.status || "published")}
        </span>
      </div>
      <p>
        ${escapeHtml(post.author || "Sarvesh Nair")}
        ${post.createdAt ? " • " + formatIST(post.createdAt) : ""}
      </p>
      <div class="post-actions">
        <button class="btn btn-outline edit-btn" data-id="${escapeHtml(post.postId)}">Edit</button>
        <button class="btn btn-danger delete-btn" data-id="${escapeHtml(post.postId)}">Delete</button>
      </div>
    </article>
  `).join("");

  document.querySelectorAll(".edit-btn").forEach((button) => {
    button.addEventListener("click", () => startEdit(button.dataset.id));
  });

  document.querySelectorAll(".delete-btn").forEach((button) => {
    button.addEventListener("click", () => deletePost(button.dataset.id));
  });
}

function startEdit(postId) {
  const post = posts.find((p) => p.postId === postId);
  if (!post) return;

  $("postId").value = post.postId || "";
  $("title").value = post.title || "";
  $("excerpt").value = post.excerpt || "";
  $("content").value = post.content || "";
  $("author").value = post.author || "Sarvesh Nair";
  $("status").value = post.status || "published";

  $("formTitle").textContent = "Edit blog post";
  $("saveBtn").textContent = "Save changes";
  $("cancelEditBtn").classList.remove("hidden");
  $("formMessage").textContent = "";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function resetForm() {
  $("blogForm").reset();
  $("postId").value = "";
  $("author").value = "Sarvesh Nair";
  $("status").value = "published";
  $("formTitle").textContent = "Create a blog post";
  $("saveBtn").textContent = "Publish post";
  $("cancelEditBtn").classList.add("hidden");
}

async function savePost(event) {
  event.preventDefault();

  const postId = $("postId").value.trim();
  const payload = {
    title: $("title").value.trim(),
    excerpt: $("excerpt").value.trim(),
    content: $("content").value.trim(),
    author: $("author").value.trim(),
    status: $("status").value
  };

  $("saveBtn").disabled = true;
  $("formMessage").textContent = "Saving…";

  try {
    if (postId) {
      // Backend route to add later:
      // PUT /blogs/{postId}
      await apiRequest(`/blogs/${encodeURIComponent(postId)}`, {
        method: "PUT",
        body: JSON.stringify(payload)
      });
    } else {
      await apiRequest("/blogs", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    }

    $("formMessage").textContent = "Saved successfully.";
    resetForm();

    const user = await manager.getUser();
    await loadPosts(user);
  } catch (err) {
    console.error(err);
    $("formMessage").textContent = err.message;
  } finally {
    $("saveBtn").disabled = false;
  }
}

async function deletePost(postId) {
  const post = posts.find((p) => p.postId === postId);
  const title = post?.title || "this post";

  if (!confirm(`Delete "${title}"?`)) return;

  try {
    // Backend route to add later:
    // DELETE /blogs/{postId}
    await apiRequest(`/blogs/${encodeURIComponent(postId)}`, {
      method: "DELETE"
    });

    const user = await manager.getUser();
    await loadPosts(user);
  } catch (err) {
    alert(
      "Delete is not enabled on the API yet.\n\n" +
      err.message +
      "\n\nWe will add the protected DELETE route in the next backend step."
    );
  }
}

function formatIST(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return new Intl.DateTimeFormat("en-IN", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Kolkata"
  }).format(date) + " IST";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

$("loginBtn").addEventListener("click", login);
$("logoutBtn").addEventListener("click", logout);
$("refreshBtn").addEventListener("click", async () => {
  const user = await manager.getUser();
  await loadPosts(user);
});
$("cancelEditBtn").addEventListener("click", resetForm);
$("blogForm").addEventListener("submit", savePost);

init().catch((err) => {
  console.error(err);
  $("loginError").textContent = err.message;
});
