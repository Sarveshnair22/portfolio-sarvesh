SARVESH NAIR PORTFOLIO - ADMIN PORTAL
=======================================

Folder:
admin/
  index.html
  style.css
  config.js
  app.js

WHAT THIS BUILD DOES
--------------------
1. Provides a Cognito login screen.
2. Uses OAuth 2.0 Authorization Code + PKCE through oidc-client-ts.
3. Reads blog posts from your existing API.
4. Provides a Create Blog form.
5. Includes Edit/Delete UI ready for the backend routes we will add next.
6. Displays dates in India Standard Time (IST).

YOUR CURRENT API
----------------
https://x6i2hkelg9.execute-api.ap-south-1.amazonaws.com/dev

CURRENT ROUTE
-------------
GET  /blogs
POST /blogs

NEXT BACKEND ROUTES
-------------------
PUT    /blogs/{postId}
DELETE /blogs/{postId}

IMPORTANT COGNITO SETTINGS
--------------------------
Before login can work, update config.js:

CLIENT_ID
- Cognito > User pool > Applications > App client
- Copy the App client ID.

COGNITO_DOMAIN
- Cognito > User pool > Branding / Managed login / Domain
- Copy the Managed Login domain.
- It will look similar to:
  https://something.auth.ap-south-1.amazoncognito.com

REDIRECT_URI
- Once this folder is deployed:
  https://www.sarveshnair.space/admin/
- This exact URL must also be added to Cognito's Allowed callback URLs.

POST_LOGOUT_REDIRECT_URI
- Add the same URL to Cognito's Allowed sign-out URLs.

DO NOT PUT
-----------
Never put AWS access keys, secret keys, or IAM credentials in this frontend.

DEPLOYMENT
----------
Copy the entire admin folder into:

/var/www/html/admin/

Then the page should be available at:

https://www.sarveshnair.space/admin/

IMPORTANT
---------
If your current web server is Apache/httpd, make sure JavaScript modules
are served correctly. The files are plain HTML/CSS/JS; no Node.js build
step is required.

After deployment, DO NOT expect login to work immediately.
We still need to:
1. Put the real Cognito App Client ID and domain in config.js.
2. Add the exact callback/sign-out URL to Cognito.
3. Add a JWT authorizer to API Gateway.
4. Protect POST/PUT/DELETE routes.
5. Create your Cognito admin user.
6. Test end-to-end.
