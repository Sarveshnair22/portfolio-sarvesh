// ============================================================
// Sarvesh Nair Portfolio Admin - configuration
// Fill in CLIENT_ID and COGNITO_DOMAIN after checking Cognito.
// Do NOT put an AWS secret/access key here.
// ============================================================

export const CONFIG = {
  // Your existing API Gateway endpoint:
  API_BASE_URL: "https://x6i2hkelg9.execute-api.ap-south-1.amazonaws.com/dev",

  // Cognito user pool issuer shown in the AWS setup page:
  COGNITO_AUTHORITY:
    "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_BQvva38aw",

  // Copy the App client ID from Cognito > Applications > App clients.
  CLIENT_ID: "PASTE_YOUR_COGNITO_APP_CLIENT_ID_HERE",

  // Exact URL where this admin page is hosted.
  // Change this if you use a different admin URL.
  REDIRECT_URI: "https://www.sarveshnair.space/admin/",

  // Same URL is convenient initially; change if you create a separate
  // logout/callback page.
  POST_LOGOUT_REDIRECT_URI: "https://www.sarveshnair.space/admin/",

  // Used only to start the Cognito Hosted UI login.
  // Paste the Cognito Managed Login domain from the Cognito console.
  // Example shape:
  // https://your-domain.auth.ap-south-1.amazoncognito.com
  COGNITO_DOMAIN: "PASTE_YOUR_COGNITO_DOMAIN_HERE"
};
